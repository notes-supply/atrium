Saturday Loaves brand kit. The logo, the mark and the palette.
